
# AKSHAR BRASS management

This is your offline factory management app project.

## How to Get APK (Easy)

1. Go to https://github.com and create a new repository.
2. Click "uploading an existing file".
3. Upload this ZIP file (do not open it).
4. Commit changes.
5. Go to Actions tab → run "Build Android APK".
6. After build finishes, download APK from Artifacts.
7. Install APK on your Android phone.
